<div class="form-group row">
    <label class="col-form-label col-sm-2 text-sm-right">Name</label>
    <div class="col-sm-10">
    {!!Form::text('category_name',null,['class'=>'form-control','placeholder'=>"category name"])!!}
    </div>
</div>