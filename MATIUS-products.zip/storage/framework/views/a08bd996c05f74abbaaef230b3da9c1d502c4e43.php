<?php $__env->startSection('content'); ?>
<div class="page-head">
          <h2 class="page-head-title">Unit</h2>
          
        </div>
        <div class="main-content container-fluid">
		<div class="card">
			<div class="card-header">
				<h5 class="card-title mb-0">Data Unit</h5>
				<a href="<?php echo e(url('product/create')); ?>" class="btn btn-pill btn-primary float-right">Add</a>
			</div>
			<table class="table table-striped">
				<thead>
				<tr>
						<th style="width:40%;">Name</th>
						<th>Category</th>
						<th>Unit</th>
						<th>Price</th>						
						<th class="d-none d-md-table-cell">Stock</th> 
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($product->product_name); ?></td>
						<td><?php echo e($product->category->category_name); ?></td>
						<td><?php echo e($product->unit->unit_name); ?></td>
						<td><?php echo e($product->price); ?></td>
						<td class="d-none d-md-table-cell"><?php echo e($product->stock); ?></td>
						<td class="table-action">
						<?php echo Form::open(['route'=>['product.destroy',$product->id],'method'=>'delete']); ?>

							<a href="<?php echo e(url('/product/'.$product->id.'/edit')); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-2 align-middle"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg></a>
							<button type="submit"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash align-middle"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg></button>
							<?php echo Form::close(); ?>

						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\products\resources\views/product/product.blade.php ENDPATH**/ ?>